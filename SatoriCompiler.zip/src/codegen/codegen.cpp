/**
 * @file codegen.cpp
 * @author Zhenjie Wei (2024108@bjtu.edu.cn)
 * @brief Code Generation
 * @date 2023-04-22
 * 
 * @copyright Copyright (c) 2023
 * 
 */