/**
 * @file parser.h
 * @author Zhenjie Wei (2024108@bjtu.edu.cn)
 * @brief Parser
 * @date 2023-04-27
 *
 * @copyright Copyright (c) 2023
 *
 */

void parserMain();