/**
 * @file ebnf.cpp
 * @author Zhenjie Wei (2024108@bjtu.edu.cn)
 * @brief EBNF Parser
 * @date 2023-04-27
 *
 * @copyright Copyright (c) 2023
 *
 */

#define _find(x, y) (x.find(y) != x.end())

#define EPSILON ""
#define END "#" // 用于表示输入串结束
#include "ebnf.h"

vector<token>::iterator findType(vector<token> &vec, vector<token>::iterator begin, int type)
{
    for (auto it = begin; it != vec.end(); it++)
    {
        if (it->type == type)
        {
            return it;
        }
    }
    return vec.end();
}

string lrtri(string str)
{
    return str.substr(1, str.length() - 2);
}

EBNFParser::EBNFParser(vector<token> ebnf_tokens, vector<string> tok_types) : tokens(ebnf_tokens), tokTypes(tok_types)
{
    for (int i = 0; i < tokTypes.size(); i++)
    {
        if (tokTypes[i] == "TERMINAL")
        {
            termType = i;
        }
        else if (tokTypes[i] == "NON_TERM")
        {
            nonTermType = i;
        }
        else if (tokTypes[i] == "EPSILON")
        {
            epsilonType = i;
        }
        else if (tokTypes[i] == "START")
        {
            startType = i;
        }
    }
    if (termType == -1 || nonTermType == -1)
    {
        error << "EBNFParser: No TERMINAL or NON_TERM type found!" << endl;
        throw runtime_error("EBNFParser: No TERMINAL or NON_TERM type found!");
    }
    for (int i = 0; i < tokens.size(); i++)
    {
        if (tokens[i].type == termType)
        {
            term t = lrtri(tokens[i].value);
            tokens[i].value = t;
            terminals.insert(t);
        }
        else if (tokens[i].type == nonTermType)
        {
            non_terms.insert(tokens[i].value);
        }
        else if (tokens[i].type == startType)
        {
            start = tokens[i].value;
            // 删除tokens中的起始符号
            tokens.erase(tokens.begin() + i--);
        }
    }
}

void EBNFParser::printRules()
{
    for (auto it = rules.begin(); it != rules.end(); it++)
    {
        for (auto it2 = it->second.begin(); it2 != it->second.end(); it2++)
        {
            cout << it->first << " ::= ";
            for (auto it3 = it2->begin(); it3 != it2->end(); it3++)
            {
                cout << *it3 << " ";
            }
            cout << endl;
        }
    }
}

void EBNFParser::parseRules()
{
    // 解析产生式，构造规则集，根据[]和{}构造相应的规则，消除左递归
    for (auto it = tokens.begin(); it != tokens.end(); it++)
    {
        if (it->type == nonTermType)
        {
            term left = it->value;
            it++;
            if (it->value != "::=")
            {
                error << "EBNFParser: Unexpected token " << it->value << " at line " << it->line;
                cout << "Expected ::= but got " << it->value << endl;
                throw runtime_error("");
            }
            it++;
            while (it != tokens.end())
            {
                vector<term> right;
                vector<term> newRight;
                if (it->type == epsilonType)
                {
                    rules[left].insert(right);
                    it++;
                    continue;
                }
                while (it != tokens.end() && it->value != "|" && it->value != ";")
                {
                    cout << it->value << endl;
                    if (it->type == termType)
                    {
                        right.push_back(lrtri(it->value));
                    }
                    else if (it->type == nonTermType)
                    {
                        right.push_back(it->value);
                    }
                    else if (it->value == "[")
                    {
                        newRight = right;
                        it++;
                        while (it->value != "]")
                        {
                            cout << "[] " << it->value << endl;
                            if (it->type == termType)
                            {
                                right.push_back(lrtri(it->value));
                            }
                            else if (it->type == nonTermType)
                            {
                                right.push_back(it->value);
                            }
                            else if (it->value == "[")
                            {
                                error << "EBNFParser: Unexpected token " << it->value << " at line " << it->line << endl;
                                throw runtime_error("");
                            }
                            else if (it->value == "{")
                            {
                                error << "EBNFParser: Unexpected token " << it->value << " at line " << it->line << endl;
                                throw runtime_error("");
                            }
                            else
                            {
                                error << "EBNFParser: Unexpected token " << it->value << " at line " << it->line << endl;
                                throw runtime_error("");
                            }
                            it++;
                        }
                    }
                    else if (it->value == "{")
                    {
                        term newLeft = left + "'";
                        terminals.insert(newLeft);
                        right.push_back(newLeft);
                        vector<term> tmpRight;
                        it++;
                        while (it->value != "}")
                        {
                            if (it->type == termType)
                            {
                                right.push_back(lrtri(it->value));
                            }
                            else if (it->type == nonTermType)
                            {
                                right.push_back(it->value);
                            }
                            else if (it->value == "[")
                            {
                                error << "EBNFParser: Unexpected token " << it->value << " at line " << it->line << endl;
                                throw runtime_error("");
                            }
                            else if (it->value == "{")
                            {
                                error << "EBNFParser: Unexpected token " << it->value << " at line " << it->line << endl;
                                throw runtime_error("");
                            }
                            else
                            {
                                error << "EBNFParser: Unexpected token " << it->value << " at line " << it->line << endl;
                                throw runtime_error("");
                            }
                            it++;
                        }
                        tmpRight.push_back(newLeft);
                        rules[newLeft].insert(tmpRight);
                        cout << "inserted " << left << "::=";
                        for (auto it2 = tmpRight.begin(); it2 != tmpRight.end(); it2++)
                        {
                            cout << *it2 << " ";
                        }
                        cout << endl;
                        rules[newLeft].insert(vector<term>());
                    }
                    else
                    {
                        error << "EBNFParser: Unexpected token " << it->value << " at line " << it->line << endl;
                        throw runtime_error("");
                    }
                    it++;
                }
                rules[left].insert(right);
                cout << "inserted " << left << "::=";
                for (auto it2 = right.begin(); it2 != right.end(); it2++)
                {
                    cout << *it2 << " ";
                }
                cout << endl;
                if (newRight.size() > 0)
                {
                    rules[left].insert(newRight);
                    cout << "inserted " << left << "::=";
                    for (auto it2 = newRight.begin(); it2 != newRight.end(); it2++)
                    {
                        cout << *it2 << " ";
                    }
                    cout << endl;
                }
                if (it->value == ";")
                {
                    break;
                }
                it++;
            }
        }
    }
}

void EBNFParser::calcFirst()
{
    for (auto it = non_terms.begin(); it != non_terms.end(); it++)
    {
        first[*it] = set<term>();
    }
    bool changed = true;
    while (changed)
    {
        changed = false;
        for (auto it = non_terms.begin(); it != non_terms.end(); it++)
        {
            for (auto it2 = rules[*it].begin(); it2 != rules[*it].end(); it2++)
            {
                if (it2->size() == 0)
                {
                    first[*it].insert(EPSILON);
                    continue;
                }
                bool allHaveEpsilon = true;
                for (auto it3 = it2->begin(); it3 != it2->end(); it3++)
                {
                    if (first[*it3].find(EPSILON) == first[*it3].end())
                    {
                        allHaveEpsilon = false;
                        break;
                    }
                }
                if (allHaveEpsilon)
                {
                    first[*it].insert(EPSILON);
                }
                for (auto it3 = it2->begin(); it3 != it2->end(); it3++)
                {
                    for (auto it4 = first[*it3].begin(); it4 != first[*it3].end(); it4++)
                    {
                        if (*it4 != EPSILON)
                        {
                            if (first[*it].find(*it4) == first[*it].end())
                            {
                                first[*it].insert(*it4);
                                changed = true;
                            }
                        }
                    }
                }
            }
        }
    }
}

void EBNFParser::calcFollow()
{
    for (auto it = non_terms.begin(); it != non_terms.end(); it++)
    {
        follow[*it] = set<term>();
    }
    follow[start].insert(END);
    bool changed = true;
    while (changed)
    {
        changed = false;
        for (auto it = non_terms.begin(); it != non_terms.end(); it++)
        {
            for (auto it2 = rules[*it].begin(); it2 != rules[*it].end(); it2++)
            {
                for (auto it3 = it2->begin(); it3 != it2->end(); it3++)
                {
                    if (_find(non_terms, *it3))
                    {
                        continue;
                    }
                    bool allHaveEpsilon = true;
                    for (auto it4 = it3 + 1; it4 != it2->end(); it4++)
                    {
                        if (first[*it4].find(EPSILON) == first[*it4].end())
                        {
                            allHaveEpsilon = false;
                            break;
                        }
                    }
                    if (allHaveEpsilon)
                    {
                        for (auto it4 = follow[*it].begin(); it4 != follow[*it].end(); it4++)
                        {
                            if (follow[*it3].find(*it4) == follow[*it3].end())
                            {
                                follow[*it3].insert(*it4);
                                changed = true;
                            }
                        }
                    }
                    for (auto it4 = it3 + 1; it4 != it2->end(); it4++)
                    {
                        for (auto it5 = first[*it4].begin(); it5 != first[*it4].end(); it5++)
                        {
                            if (*it5 != EPSILON)
                            {
                                if (follow[*it3].find(*it5) == follow[*it3].end())
                                {
                                    follow[*it3].insert(*it5);
                                    changed = true;
                                }
                            }
                        }
                    }
                }
            }
        }
    }
}